export default {
  roleId: '角色id',
  roleName: '角色名称',
  remark: '备注',
  createUserId: '创建者ID',
  bizType: '业务类型 0平台菜单 1 店铺菜单',
  tenantId: '所属租户'
}
