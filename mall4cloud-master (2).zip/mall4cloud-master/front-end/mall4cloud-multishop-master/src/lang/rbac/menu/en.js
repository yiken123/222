export default {
  menuId: 'menu id',
  parentId: 'parent id',
  bizType: 'biz type',
  permission: 'permission',
  path: 'path',
  component: 'component',
  redirect: 'redirect',
  alwaysShow: 'always show',
  hidden: 'hidden',
  name: 'name',
  title: 'title',
  icon: 'icon',
  noCache: 'no cache',
  breadcrumb: 'breadcrumb',
  affix: 'affix',
  activeMenu: 'active menu',
  seq: 'seq'
}
