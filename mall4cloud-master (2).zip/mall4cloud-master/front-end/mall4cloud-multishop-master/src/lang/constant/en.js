export default {
  noNull: 'No null',
  product: 'Product',
  shop: 'Shop',
  contactName: 'Contact person',
  contactTel: 'Contact number',
  consignee: 'consignee',
  mobilePhone: 'Mobile phone',
  deliveryAddr: ' delivery address',
  name: 'Name',
  dollar: ' Dollar ',
  piece: 'Pieces',
  normal: 'Normal'
}
