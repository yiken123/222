export default {
  areaId: '',
  areaName: '地址',
  parentId: '上级地址',
  level: '等级（从1开始）'
}
