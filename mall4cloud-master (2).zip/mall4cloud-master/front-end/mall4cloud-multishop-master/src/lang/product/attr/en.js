export default {
  attrId: 'attr id',
  name: 'name',
  desc: 'desc',
  searchType: 'search type',
  attrType: 'attr type'
}
