export default {
  attrId: 'attr id',
  name: '属性名称',
  desc: '属性描述',
  searchType: '是否搜索',
  attrType: '属性类型',
  attrValue: '属性值'
}
