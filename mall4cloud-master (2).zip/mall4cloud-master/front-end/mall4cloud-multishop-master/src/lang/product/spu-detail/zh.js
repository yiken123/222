export default {
  spuId: '商品id',
  detail: '商品详情'
}
