export default {
  spuId: 'spu id',
  detail: 'detail'
}
