export default {
  receiverTelephone: '公司座机',
  postalCode: '邮政编码',
  province: '省份',
  city: '城市',
  area: '区/县',
  detailed: '详细地址',
  addr: '地址',
  defaultAddr: '默认'
}
