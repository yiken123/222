export default {
  receiverTelephone: 'Receiver telephone',
  postalCode: 'Postal code',
  province: 'Province',
  city: 'City',
  area: 'Area',
  detailed: 'Detailed address',
  addr: 'Address',
  defaultAddr: 'Default addr'
}
