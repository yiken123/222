export default {
  carouselImg: 'Carousel pictures',
  recommImgSize: 'Carousel pictures',
  carouselImgNoNull: 'Carousel picture cannot be empty',
  sortNONull: 'Sort value cannot be empty',
  weChatPay: 'WeChat Pay',
  aliPay: 'Pay with Ali-Pay',
  balancePay: 'Balance Pay',
  add: 'Add',
  remove: 'Remove',
  dollar: ' dollar '
}
