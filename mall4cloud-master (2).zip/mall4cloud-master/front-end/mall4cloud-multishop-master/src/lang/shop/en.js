export default {
  contactTel: 'Contact number',
  phone: 'Phone number'
}
