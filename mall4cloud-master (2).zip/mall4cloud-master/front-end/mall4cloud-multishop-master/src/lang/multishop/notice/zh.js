export default {
  id: '公告id',
  shopId: '店铺id',
  title: '公告标题',
  content: '公告内容',
  type: '类型',
  status: '状态',
  isTop: '是否置顶',
  publishTime: '发布时间'
}
