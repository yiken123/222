export default {
  shopUserId: 'shop user id',
  shopId: 'shop id',
  nickName: 'nick name',
  avatar: 'avatar',
  code: 'code',
  phoneNum: 'phone num',
  hasAccount: 'has account'
}
